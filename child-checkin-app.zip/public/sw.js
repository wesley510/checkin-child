const CACHE_NAME = "child-checkin-v4"
const urlsToCache = ["/", "/dashboard", "/login", "/manifest.json", "/offline"]

// Install event
self.addEventListener("install", (event) => {
  console.log("🔧 Service Worker installing...")
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("📦 Caching app shell...")
      return cache.addAll(urlsToCache)
    }),
  )
  self.skipWaiting()
})

// Activate event
self.addEventListener("activate", (event) => {
  console.log("🚀 Service Worker activating...")
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log("🗑️ Deleting old cache:", cacheName)
            return caches.delete(cacheName)
          }
        }),
      )
    }),
  )
  self.clients.claim()
})

// Fetch event - Network first, then cache
self.addEventListener("fetch", (event) => {
  // Skip non-GET requests
  if (event.request.method !== "GET") {
    return
  }

  // Skip external requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // If we got a valid response, clone it and cache it
        if (response && response.status === 200 && response.type === "basic") {
          const responseToCache = response.clone()
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache)
          })
        }
        return response
      })
      .catch(() => {
        // Network failed, try cache
        return caches.match(event.request).then((response) => {
          if (response) {
            console.log("📱 Serving from cache:", event.request.url)
            return response
          }

          // If it's a navigation request and we don't have it cached, return offline page
          if (event.request.mode === "navigate") {
            return caches.match("/offline") || new Response("Offline", { status: 503 })
          }

          // For other requests, return a generic offline response
          return new Response("Offline", { status: 503 })
        })
      }),
  )
})

// Background sync
self.addEventListener("sync", (event) => {
  console.log("🔄 Background sync triggered:", event.tag)
  if (event.tag === "background-sync") {
    event.waitUntil(doBackgroundSync())
  }
})

function doBackgroundSync() {
  return new Promise((resolve) => {
    console.log("📡 Triggering background sync in main app...")
    self.clients.matchAll().then((clients) => {
      clients.forEach((client) => {
        client.postMessage({ type: "BACKGROUND_SYNC" })
      })
    })
    resolve()
  })
}

// Push notifications
self.addEventListener("push", (event) => {
  console.log("📢 Push notification received")
  const options = {
    body: event.data ? event.data.text() : "New notification from Child Check-In",
    icon: "/icon-192x192.png",
    badge: "/icon-192x192.png",
    tag: "child-checkin-notification",
    requireInteraction: true,
  }

  event.waitUntil(self.registration.showNotification("Child Check-In", options))
})

// Message handling
self.addEventListener("message", (event) => {
  console.log("💬 Message received:", event.data)
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting()
  }
})

// Handle notification clicks
self.addEventListener("notificationclick", (event) => {
  console.log("🔔 Notification clicked")
  event.notification.close()

  event.waitUntil(
    clients.matchAll().then((clientList) => {
      if (clientList.length > 0) {
        return clientList[0].focus()
      }
      return clients.openWindow("/dashboard")
    }),
  )
})
