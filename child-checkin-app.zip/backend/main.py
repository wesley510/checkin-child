from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import sqlite3
import hashlib
import jwt
from datetime import datetime, timedelta
import os

app = FastAPI(title="Child Check-In API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
DATABASE_URL = "checkin.db"
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here")

def init_db():
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'PARENT',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Children table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS children (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            grade TEXT NOT NULL,
            parent_id INTEGER NOT NULL,
            status TEXT DEFAULT 'CHECKED_OUT',
            location TEXT DEFAULT 'Home',
            last_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (parent_id) REFERENCES users (id)
        )
    ''')
    
    # Check-in records table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS checkin_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER NOT NULL,
            parent_id INTEGER,
            admin_id INTEGER,
            action TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (child_id) REFERENCES children (id),
            FOREIGN KEY (parent_id) REFERENCES users (id),
            FOREIGN KEY (admin_id) REFERENCES users (id)
        )
    ''')
    
    # Requests table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            child_id INTEGER NOT NULL,
            parent_id INTEGER NOT NULL,
            admin_id INTEGER,
            request_type TEXT NOT NULL,
            status TEXT DEFAULT 'PENDING',
            reason TEXT,
            admin_reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            responded_at TIMESTAMP,
            FOREIGN KEY (child_id) REFERENCES children (id),
            FOREIGN KEY (parent_id) REFERENCES users (id),
            FOREIGN KEY (admin_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database
init_db()

# Pydantic models
class UserCreate(BaseModel):
    email: str
    password: str
    name: str
    role: str = "PARENT"

class UserLogin(BaseModel):
    email: str
    password: str

class ChildCreate(BaseModel):
    name: str
    grade: str
    parent_id: int

class CheckInOut(BaseModel):
    parent_id: Optional[int] = None
    admin_id: Optional[int] = None

class RequestCreate(BaseModel):
    child_id: int
    parent_id: int
    request_type: str  # 'CHECK_IN' or 'CHECK_OUT'
    reason: Optional[str] = ""

class RequestResponse(BaseModel):
    admin_id: int
    action: str  # 'APPROVE' or 'REJECT'
    reason: Optional[str] = ""

# Helper functions
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    return hash_password(password) == hashed

def create_token(user_id: int) -> str:
    payload = {
        "user_id": user_id,
        "exp": datetime.utcnow() + timedelta(days=7)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

# Routes
@app.get("/api/health")
async def health_check():
    return {"status": "UP", "message": "Child Check-In API is running"}

@app.post("/api/auth/register")
async def register(user: UserCreate):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    try:
        hashed_password = hash_password(user.password)
        cursor.execute(
            "INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)",
            (user.email, hashed_password, user.name, user.role.upper())
        )
        user_id = cursor.lastrowid
        conn.commit()
        
        # Get the created user
        cursor.execute("SELECT id, email, name, role FROM users WHERE id = ?", (user_id,))
        user_data = cursor.fetchone()
        
        return {
            "success": True,
            "user": {
                "id": user_data[0],
                "email": user_data[1],
                "name": user_data[2],
                "role": user_data[3]
            },
            "token": create_token(user_id)
        }
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Email already registered")
    finally:
        conn.close()

@app.post("/api/auth/login")
async def login(credentials: UserLogin):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, email, name, role, password FROM users WHERE email = ?", (credentials.email,))
    user = cursor.fetchone()
    conn.close()
    
    if not user or not verify_password(credentials.password, user[4]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    return {
        "success": True,
        "user": {
            "id": user[0],
            "email": user[1],
            "name": user[2],
            "role": user[3]
        },
        "token": create_token(user[0])
    }

@app.get("/api/children/all")
async def get_all_children():
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT c.id, c.name, c.grade, c.parent_id, c.status, c.location, c.last_update, u.email
        FROM children c
        JOIN users u ON c.parent_id = u.id
    ''')
    children = cursor.fetchall()
    conn.close()
    
    return [
        {
            "id": child[0],
            "name": child[1],
            "grade": child[2],
            "parentId": child[3],
            "status": child[4],
            "location": child[5],
            "lastUpdate": child[6],
            "parentEmail": child[7]
        }
        for child in children
    ]

@app.get("/api/children/parent/{parent_id}")
async def get_children_by_parent(parent_id: int):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute(
        "SELECT id, name, grade, parent_id, status, location, last_update FROM children WHERE parent_id = ?",
        (parent_id,)
    )
    children = cursor.fetchall()
    conn.close()
    
    return [
        {
            "id": child[0],
            "name": child[1],
            "grade": child[2],
            "parentId": child[3],
            "status": child[4],
            "location": child[5],
            "lastUpdate": child[6]
        }
        for child in children
    ]

@app.post("/api/children")
async def create_child(child: ChildCreate):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute(
        "INSERT INTO children (name, grade, parent_id) VALUES (?, ?, ?)",
        (child.name, child.grade, child.parent_id)
    )
    child_id = cursor.lastrowid
    conn.commit()
    
    # Get the created child
    cursor.execute(
        "SELECT id, name, grade, parent_id, status, location, last_update FROM children WHERE id = ?",
        (child_id,)
    )
    child_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": child_data[0],
        "name": child_data[1],
        "grade": child_data[2],
        "parentId": child_data[3],
        "status": child_data[4],
        "location": child_data[5],
        "lastUpdate": child_data[6]
    }

# Request endpoints
@app.post("/api/requests")
async def create_request(request: RequestCreate):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute(
        "INSERT INTO requests (child_id, parent_id, request_type, reason) VALUES (?, ?, ?, ?)",
        (request.child_id, request.parent_id, request.request_type, request.reason)
    )
    request_id = cursor.lastrowid
    conn.commit()
    
    # Get the created request with child and parent info
    cursor.execute('''
        SELECT r.id, r.child_id, r.parent_id, r.request_type, r.status, r.reason, 
               r.created_at, c.name as child_name, u.name as parent_name, u.email as parent_email
        FROM requests r
        JOIN children c ON r.child_id = c.id
        JOIN users u ON r.parent_id = u.id
        WHERE r.id = ?
    ''', (request_id,))
    request_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": request_data[0],
        "childId": request_data[1],
        "parentId": request_data[2],
        "requestType": request_data[3],
        "status": request_data[4],
        "reason": request_data[5],
        "createdAt": request_data[6],
        "childName": request_data[7],
        "parentName": request_data[8],
        "parentEmail": request_data[9]
    }

@app.get("/api/requests/pending")
async def get_pending_requests():
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT r.id, r.child_id, r.parent_id, r.request_type, r.status, r.reason, 
               r.created_at, c.name as child_name, c.grade, u.name as parent_name, u.email as parent_email
        FROM requests r
        JOIN children c ON r.child_id = c.id
        JOIN users u ON r.parent_id = u.id
        WHERE r.status = 'PENDING'
        ORDER BY r.created_at DESC
    ''')
    requests = cursor.fetchall()
    conn.close()
    
    return [
        {
            "id": req[0],
            "childId": req[1],
            "parentId": req[2],
            "requestType": req[3],
            "status": req[4],
            "reason": req[5],
            "createdAt": req[6],
            "childName": req[7],
            "childGrade": req[8],
            "parentName": req[9],
            "parentEmail": req[10]
        }
        for req in requests
    ]

@app.get("/api/requests/parent/{parent_id}")
async def get_parent_requests(parent_id: int):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT r.id, r.child_id, r.parent_id, r.request_type, r.status, r.reason, 
               r.admin_reason, r.created_at, r.responded_at, c.name as child_name,
               a.name as admin_name
        FROM requests r
        JOIN children c ON r.child_id = c.id
        LEFT JOIN users a ON r.admin_id = a.id
        WHERE r.parent_id = ?
        ORDER BY r.created_at DESC
    ''')
    requests = cursor.fetchall()
    conn.close()
    
    return [
        {
            "id": req[0],
            "childId": req[1],
            "parentId": req[2],
            "requestType": req[3],
            "status": req[4],
            "reason": req[5],
            "adminReason": req[6],
            "createdAt": req[7],
            "respondedAt": req[8],
            "childName": req[9],
            "adminName": req[10]
        }
        for req in requests
    ]

@app.put("/api/requests/{request_id}/respond")
async def respond_to_request(request_id: int, response: RequestResponse):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Update the request
    cursor.execute(
        "UPDATE requests SET status = ?, admin_id = ?, admin_reason = ?, responded_at = CURRENT_TIMESTAMP WHERE id = ?",
        (response.action, response.admin_id, response.reason, request_id)
    )
    
    # If approved, update child status
    if response.action == 'APPROVE':
        cursor.execute("SELECT child_id, request_type FROM requests WHERE id = ?", (request_id,))
        request_data = cursor.fetchone()
        
        if request_data:
            child_id, request_type = request_data
            new_status = 'CHECKED_IN' if request_type == 'CHECK_IN' else 'CHECKED_OUT'
            new_location = 'School' if request_type == 'CHECK_IN' else 'Home'
            
            cursor.execute(
                "UPDATE children SET status = ?, location = ?, last_update = CURRENT_TIMESTAMP WHERE id = ?",
                (new_status, new_location, child_id)
            )
            
            # Record the action
            action_type = f"ADMIN_{request_type}"
            cursor.execute(
                "INSERT INTO checkin_records (child_id, admin_id, action) VALUES (?, ?, ?)",
                (child_id, response.admin_id, action_type)
            )
    
    conn.commit()
    
    # Get updated request
    cursor.execute('''
        SELECT r.id, r.child_id, r.parent_id, r.request_type, r.status, r.reason, 
               r.admin_reason, r.created_at, r.responded_at, c.name as child_name
        FROM requests r
        JOIN children c ON r.child_id = c.id
        WHERE r.id = ?
    ''', (request_id,))
    request_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": request_data[0],
        "childId": request_data[1],
        "parentId": request_data[2],
        "requestType": request_data[3],
        "status": request_data[4],
        "reason": request_data[5],
        "adminReason": request_data[6],
        "createdAt": request_data[7],
        "respondedAt": request_data[8],
        "childName": request_data[9]
    }

# Original check-in/out endpoints (kept for direct admin actions)
@app.put("/api/children/{child_id}/checkin")
async def check_in_child(child_id: int, data: CheckInOut):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Update child status
    cursor.execute(
        "UPDATE children SET status = 'CHECKED_IN', location = 'School', last_update = CURRENT_TIMESTAMP WHERE id = ?",
        (child_id,)
    )
    
    # Record the check-in
    cursor.execute(
        "INSERT INTO checkin_records (child_id, parent_id, action) VALUES (?, ?, 'CHECK_IN')",
        (child_id, data.parent_id)
    )
    
    conn.commit()
    
    # Get updated child
    cursor.execute(
        "SELECT id, name, grade, parent_id, status, location, last_update FROM children WHERE id = ?",
        (child_id,)
    )
    child_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": child_data[0],
        "name": child_data[1],
        "grade": child_data[2],
        "parentId": child_data[3],
        "status": child_data[4],
        "location": child_data[5],
        "lastUpdate": child_data[6]
    }

@app.put("/api/children/{child_id}/checkout")
async def check_out_child(child_id: int, data: CheckInOut):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Update child status
    cursor.execute(
        "UPDATE children SET status = 'CHECKED_OUT', location = 'Home', last_update = CURRENT_TIMESTAMP WHERE id = ?",
        (child_id,)
    )
    
    # Record the check-out
    cursor.execute(
        "INSERT INTO checkin_records (child_id, parent_id, action) VALUES (?, ?, 'CHECK_OUT')",
        (child_id, data.parent_id)
    )
    
    conn.commit()
    
    # Get updated child
    cursor.execute(
        "SELECT id, name, grade, parent_id, status, location, last_update FROM children WHERE id = ?",
        (child_id,)
    )
    child_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": child_data[0],
        "name": child_data[1],
        "grade": child_data[2],
        "parentId": child_data[3],
        "status": child_data[4],
        "location": child_data[5],
        "lastUpdate": child_data[6]
    }

@app.put("/api/admin/children/{child_id}/checkin")
async def admin_check_in_child(child_id: int, data: CheckInOut):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Update child status
    cursor.execute(
        "UPDATE children SET status = 'CHECKED_IN', location = 'School', last_update = CURRENT_TIMESTAMP WHERE id = ?",
        (child_id,)
    )
    
    # Record the admin check-in
    cursor.execute(
        "INSERT INTO checkin_records (child_id, admin_id, action) VALUES (?, ?, 'ADMIN_CHECK_IN')",
        (child_id, data.admin_id)
    )
    
    conn.commit()
    
    # Get updated child
    cursor.execute(
        "SELECT id, name, grade, parent_id, status, location, last_update FROM children WHERE id = ?",
        (child_id,)
    )
    child_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": child_data[0],
        "name": child_data[1],
        "grade": child_data[2],
        "parentId": child_data[3],
        "status": child_data[4],
        "location": child_data[5],
        "lastUpdate": child_data[6]
    }

@app.put("/api/admin/children/{child_id}/checkout")
async def admin_check_out_child(child_id: int, data: CheckInOut):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Update child status
    cursor.execute(
        "UPDATE children SET status = 'CHECKED_OUT', location = 'Home', last_update = CURRENT_TIMESTAMP WHERE id = ?",
        (child_id,)
    )
    
    # Record the admin check-out
    cursor.execute(
        "INSERT INTO checkin_records (child_id, admin_id, action) VALUES (?, ?, 'ADMIN_CHECK_OUT')",
        (child_id, data.admin_id)
    )
    
    conn.commit()
    
    # Get updated child
    cursor.execute(
        "SELECT id, name, grade, parent_id, status, location, last_update FROM children WHERE id = ?",
        (child_id,)
    )
    child_data = cursor.fetchone()
    conn.close()
    
    return {
        "id": child_data[0],
        "name": child_data[1],
        "grade": child_data[2],
        "parentId": child_data[3],
        "status": child_data[4],
        "location": child_data[5],
        "lastUpdate": child_data[6]
    }

@app.delete("/api/children/{child_id}")
async def delete_child(child_id: int):
    conn = sqlite3.connect(DATABASE_URL)
    cursor = conn.cursor()
    
    # Delete child records first
    cursor.execute("DELETE FROM checkin_records WHERE child_id = ?", (child_id,))
    cursor.execute("DELETE FROM requests WHERE child_id = ?", (child_id,))
    cursor.execute("DELETE FROM children WHERE id = ?", (child_id,))
    
    conn.commit()
    conn.close()
    
    return {"success": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
