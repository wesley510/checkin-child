package com.childcheckin.controller;

import com.childcheckin.model.Child;
import com.childcheckin.service.ChildService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/children")
@CrossOrigin(origins = "*")
public class ChildController {
    
    @Autowired
    private ChildService childService;
    
    @GetMapping("/parent/{parentId}")
    public ResponseEntity<List<Child>> getChildrenByParent(@PathVariable Long parentId) {
        List<Child> children = childService.getChildrenByParent(parentId);
        return ResponseEntity.ok(children);
    }
    
    @GetMapping("/all")
    public ResponseEntity<List<Child>> getAllChildren() {
        List<Child> children = childService.getAllChildren();
        return ResponseEntity.ok(children);
    }
    
    @PostMapping
    public ResponseEntity<?> createChild(@RequestBody Map<String, Object> childData) {
        try {
            String name = (String) childData.get("name");
            String grade = (String) childData.get("grade");
            Long parentId = Long.valueOf(childData.get("parentId").toString());
            
            Child child = childService.createChild(name, grade, parentId);
            return ResponseEntity.ok(child);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @PutMapping("/{childId}/checkin")
    public ResponseEntity<?> checkIn(@PathVariable Long childId, @RequestBody Map<String, Object> data) {
        try {
            Long parentId = Long.valueOf(data.get("parentId").toString());
            Child child = childService.checkIn(childId, parentId);
            return ResponseEntity.ok(child);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @PutMapping("/{childId}/checkout")
    public ResponseEntity<?> checkOut(@PathVariable Long childId, @RequestBody Map<String, Object> data) {
        try {
            Long parentId = Long.valueOf(data.get("parentId").toString());
            Child child = childService.checkOut(childId, parentId);
            return ResponseEntity.ok(child);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
    
    @DeleteMapping("/{childId}")
    public ResponseEntity<?> deleteChild(@PathVariable Long childId) {
        try {
            childService.deleteChild(childId);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", e.getMessage()
            ));
        }
    }
}
