package com.childcheckin.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "checkin_records")
public class CheckinRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "child_id")
    private Child child;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private User parent;
    
    @Enumerated(EnumType.STRING)
    private Action action;
    
    private LocalDateTime timestamp = LocalDateTime.now();
    
    public enum Action {
        CHECK_IN, CHECK_OUT
    }
    
    // Constructors
    public CheckinRecord() {}
    
    public CheckinRecord(Child child, User parent, Action action) {
        this.child = child;
        this.parent = parent;
        this.action = action;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Child getChild() { return child; }
    public void setChild(Child child) { this.child = child; }
    
    public User getParent() { return parent; }
    public void setParent(User parent) { this.parent = parent; }
    
    public Action getAction() { return action; }
    public void setAction(Action action) { this.action = action; }
    
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
