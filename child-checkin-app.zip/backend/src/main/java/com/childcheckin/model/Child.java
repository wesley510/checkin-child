package com.childcheckin.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "children")
public class Child {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    private String grade;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private User parent;
    
    @Enumerated(EnumType.STRING)
    private Status status = Status.CHECKED_OUT;
    
    private LocalDateTime lastUpdate = LocalDateTime.now();
    
    public enum Status {
        CHECKED_IN, CHECKED_OUT
    }
    
    // Constructors
    public Child() {}
    
    public Child(String name, String grade, User parent) {
        this.name = name;
        this.grade = grade;
        this.parent = parent;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }
    
    public User getParent() { return parent; }
    public void setParent(User parent) { this.parent = parent; }
    
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    
    public LocalDateTime getLastUpdate() { return lastUpdate; }
    public void setLastUpdate(LocalDateTime lastUpdate) { this.lastUpdate = lastUpdate; }
}
