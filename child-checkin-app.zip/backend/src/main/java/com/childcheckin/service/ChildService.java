package com.childcheckin.service;

import com.childcheckin.model.Child;
import com.childcheckin.model.CheckinRecord;
import com.childcheckin.model.User;
import com.childcheckin.repository.ChildRepository;
import com.childcheckin.repository.CheckinRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class ChildService {
    
    @Autowired
    private ChildRepository childRepository;
    
    @Autowired
    private CheckinRecordRepository checkinRecordRepository;
    
    @Autowired
    private UserService userService;
    
    public List<Child> getChildrenByParent(Long parentId) {
        return childRepository.findByParentId(parentId);
    }
    
    public List<Child> getAllChildren() {
        return childRepository.findAll();
    }
    
    public Child createChild(String name, String grade, Long parentId) {
        Optional<User> parentOpt = userService.findById(parentId);
        if (!parentOpt.isPresent()) {
            throw new RuntimeException("Parent not found");
        }
        
        Child child = new Child(name, grade, parentOpt.get());
        return childRepository.save(child);
    }
    
    public Child checkIn(Long childId, Long parentId) {
        Optional<Child> childOpt = childRepository.findById(childId);
        Optional<User> parentOpt = userService.findById(parentId);
        
        if (!childOpt.isPresent()) {
            throw new RuntimeException("Child not found");
        }
        
        if (!parentOpt.isPresent()) {
            throw new RuntimeException("Parent not found");
        }
        
        Child child = childOpt.get();
        User parent = parentOpt.get();
        
        child.setStatus(Child.Status.CHECKED_IN);
        child.setLastUpdate(LocalDateTime.now());
        
        // Create check-in record
        CheckinRecord record = new CheckinRecord(child, parent, CheckinRecord.Action.CHECK_IN);
        checkinRecordRepository.save(record);
        
        return childRepository.save(child);
    }
    
    public Child checkOut(Long childId, Long parentId) {
        Optional<Child> childOpt = childRepository.findById(childId);
        Optional<User> parentOpt = userService.findById(parentId);
        
        if (!childOpt.isPresent()) {
            throw new RuntimeException("Child not found");
        }
        
        if (!parentOpt.isPresent()) {
            throw new RuntimeException("Parent not found");
        }
        
        Child child = childOpt.get();
        User parent = parentOpt.get();
        
        child.setStatus(Child.Status.CHECKED_OUT);
        child.setLastUpdate(LocalDateTime.now());
        
        // Create check-out record
        CheckinRecord record = new CheckinRecord(child, parent, CheckinRecord.Action.CHECK_OUT);
        checkinRecordRepository.save(record);
        
        return childRepository.save(child);
    }
    
    public void deleteChild(Long childId) {
        childRepository.deleteById(childId);
    }
}
