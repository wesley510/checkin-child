package com.childcheckin.service;

import com.childcheckin.model.User;
import com.childcheckin.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    public User authenticate(String email, String password) {
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            // In production, use proper password hashing (BCrypt)
            if (password.equals(user.getPassword())) {
                user.setLastLogin(LocalDateTime.now());
                return userRepository.save(user);
            }
        }
        return null;
    }
    
    public User createUser(String email, String password, String name, User.Role role) {
        // Check if user already exists
        if (userRepository.findByEmail(email).isPresent()) {
            throw new RuntimeException("User with this email already exists");
        }
        
        User user = new User(email, password, name, role);
        return userRepository.save(user);
    }
    
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }
    
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}
