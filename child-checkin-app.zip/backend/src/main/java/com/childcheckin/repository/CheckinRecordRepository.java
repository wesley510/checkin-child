package com.childcheckin.repository;

import com.childcheckin.model.CheckinRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CheckinRepository extends JpaRepository<CheckinRecord, Long> {
    List<CheckinRecord> findByParentIdOrderByTimestampDesc(Long parentId);
}
