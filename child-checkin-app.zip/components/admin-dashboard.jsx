"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Shield,
  Users,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  LogIn,
  LogOut,
  Activity,
  UserCheck,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { SyncStatus } from "@/components/sync-status"
import { ThemeToggle } from "@/components/theme-toggle"

export function AdminDashboard() {
  const [children, setChildren] = useState([])
  const [requests, setRequests] = useState([])
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [responseReason, setResponseReason] = useState("")
  const [isOnline, setIsOnline] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    loadData()

    // Check online status
    setIsOnline(navigator.onLine)
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  const loadData = () => {
    try {
      const savedChildren = localStorage.getItem("children")
      const savedRequests = localStorage.getItem("requests")

      if (savedChildren) {
        setChildren(JSON.parse(savedChildren))
      }

      if (savedRequests) {
        setRequests(JSON.parse(savedRequests))
      }
    } catch (error) {
      console.error("Error loading data:", error)
    }
  }

  const saveData = (newChildren, newRequests) => {
    try {
      if (newChildren) {
        localStorage.setItem("children", JSON.stringify(newChildren))
      }
      if (newRequests) {
        localStorage.setItem("requests", JSON.stringify(newRequests))
      }
    } catch (error) {
      console.error("Error saving data:", error)
    }
  }

  const handleRequest = (requestId, action, reason = "") => {
    const request = requests.find((r) => r.id === requestId)
    if (!request) return

    // Update request status
    const updatedRequests = requests.map((r) =>
      r.id === requestId
        ? {
            ...r,
            status: action,
            adminResponse: reason,
            processedAt: new Date().toISOString(),
          }
        : r,
    )

    // If approved, update child status
    let updatedChildren = children
    if (action === "approved") {
      updatedChildren = children.map((child) =>
        child.id === request.childId
          ? {
              ...child,
              status: request.action,
              lastUpdated: new Date().toISOString(),
            }
          : child,
      )
    }

    setRequests(updatedRequests)
    setChildren(updatedChildren)
    saveData(updatedChildren, updatedRequests)

    setSelectedRequest(null)
    setResponseReason("")

    toast({
      title: action === "approved" ? "Request Approved" : "Request Rejected",
      description: `${request.childName}'s ${request.action === "in" ? "check-in" : "check-out"} request has been ${action}`,
      variant: action === "approved" ? "default" : "destructive",
    })
  }

  const overrideChildStatus = (childId, newStatus) => {
    const updatedChildren = children.map((child) =>
      child.id === childId
        ? {
            ...child,
            status: newStatus,
            lastUpdated: new Date().toISOString(),
            overriddenBy: "admin",
          }
        : child,
    )

    setChildren(updatedChildren)
    saveData(updatedChildren, null)

    const child = children.find((c) => c.id === childId)
    toast({
      title: "Status Updated",
      description: `${child?.name} has been marked as ${newStatus === "in" ? "checked in" : "checked out"}`,
    })
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "in":
        return "bg-green-500"
      case "out":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getRequestStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getRequestIcon = (status) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "rejected":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const pendingRequests = requests.filter((r) => r.status === "pending")
  const recentRequests = requests.slice(-10).reverse()
  const checkedInCount = children.filter((c) => c.status === "in").length
  const checkedOutCount = children.filter((c) => c.status === "out").length

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-3">
            <div className="bg-red-600 p-2 rounded-lg">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
              <p className="text-gray-600 dark:text-gray-300">Manage check-in requests and child status</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <SyncStatus />
            <ThemeToggle />
          </div>
        </div>

        {!isOnline && (
          <Alert className="mb-6 border-orange-200 bg-orange-50 dark:bg-orange-900/20">
            <AlertCircle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800 dark:text-orange-200">
              You're currently offline. Changes will be synced when connection is restored.
            </AlertDescription>
          </Alert>
        )}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Total Children</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{children.length}</p>
                </div>
                <Users className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Checked In</p>
                  <p className="text-2xl font-bold text-green-600">{checkedInCount}</p>
                </div>
                <UserCheck className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Checked Out</p>
                  <p className="text-2xl font-bold text-red-600">{checkedOutCount}</p>
                </div>
                <LogOut className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Pending Requests</p>
                  <p className="text-2xl font-bold text-orange-600">{pendingRequests.length}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Pending Requests */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Pending Requests ({pendingRequests.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pendingRequests.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No pending requests</p>
                    <p className="text-sm">All requests have been processed</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingRequests.map((request) => (
                      <div key={request.id} className="p-4 border rounded-lg dark:border-gray-700">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h3 className="font-semibold text-gray-900 dark:text-white">{request.childName}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-300">
                              {request.action === "in" ? "Check-in" : "Check-out"} request
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {new Date(request.timestamp).toLocaleString()}
                            </p>
                          </div>
                          <Badge variant={getRequestStatusColor(request.status)}>
                            {getRequestIcon(request.status)}
                            <span className="ml-1">{request.status}</span>
                          </Badge>
                        </div>
                        <div className="flex space-x-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" onClick={() => setSelectedRequest(request)}>
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Approve
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Approve Request</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <p>
                                  Approve {request.childName}'s {request.action === "in" ? "check-in" : "check-out"}{" "}
                                  request?
                                </p>
                                <div>
                                  <label className="text-sm font-medium">Response (optional)</label>
                                  <Textarea
                                    value={responseReason}
                                    onChange={(e) => setResponseReason(e.target.value)}
                                    placeholder="Add a note..."
                                    className="mt-1"
                                  />
                                </div>
                                <div className="flex justify-end space-x-2">
                                  <Button variant="outline" onClick={() => setSelectedRequest(null)}>
                                    Cancel
                                  </Button>
                                  <Button onClick={() => handleRequest(request.id, "approved", responseReason)}>
                                    Approve
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="destructive" onClick={() => setSelectedRequest(request)}>
                                <XCircle className="h-4 w-4 mr-1" />
                                Reject
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Reject Request</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <p>
                                  Reject {request.childName}'s {request.action === "in" ? "check-in" : "check-out"}{" "}
                                  request?
                                </p>
                                <div>
                                  <label className="text-sm font-medium">Reason for rejection</label>
                                  <Textarea
                                    value={responseReason}
                                    onChange={(e) => setResponseReason(e.target.value)}
                                    placeholder="Please provide a reason..."
                                    className="mt-1"
                                  />
                                </div>
                                <div className="flex justify-end space-x-2">
                                  <Button variant="outline" onClick={() => setSelectedRequest(null)}>
                                    Cancel
                                  </Button>
                                  <Button
                                    variant="destructive"
                                    onClick={() => handleRequest(request.id, "rejected", responseReason)}
                                  >
                                    Reject
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* All Children Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  All Children ({children.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {children.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No children registered</p>
                    <p className="text-sm">Children will appear here when parents add them</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {children.map((child) => (
                      <div
                        key={child.id}
                        className="flex items-center justify-between p-4 border rounded-lg dark:border-gray-700"
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(child.status)}`} />
                          <div>
                            <h3 className="font-semibold text-gray-900 dark:text-white">{child.name}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-300">{child.grade}</p>
                            {child.lastUpdated && (
                              <p className="text-xs text-gray-500 dark:text-gray-400">
                                Last updated: {new Date(child.lastUpdated).toLocaleString()}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={child.status === "in" ? "default" : "secondary"}>
                            {child.status === "in" ? "Checked In" : "Checked Out"}
                          </Badge>
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              variant={child.status === "in" ? "outline" : "default"}
                              onClick={() => overrideChildStatus(child.id, "in")}
                              disabled={child.status === "in"}
                            >
                              <LogIn className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant={child.status === "out" ? "outline" : "default"}
                              onClick={() => overrideChildStatus(child.id, "out")}
                              disabled={child.status === "out"}
                            >
                              <LogOut className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recentRequests.length === 0 ? (
                  <p className="text-gray-500 dark:text-gray-400 text-sm text-center py-4">No recent activity</p>
                ) : (
                  <div className="space-y-3">
                    {recentRequests.map((request) => (
                      <div key={request.id} className="p-3 border rounded-lg dark:border-gray-700">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900 dark:text-white">{request.childName}</span>
                          <Badge variant={getRequestStatusColor(request.status)}>
                            {getRequestIcon(request.status)}
                            <span className="ml-1">{request.status}</span>
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {request.action === "in" ? "Check-in" : "Check-out"} request
                        </p>
                        {request.adminResponse && (
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            Response: {request.adminResponse}
                          </p>
                        )}
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(request.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
