"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { WifiOff, RefreshCw, CheckCircle } from "lucide-react"

export function SyncStatus() {
  const [isOnline, setIsOnline] = useState(true)
  const [syncing, setSyncing] = useState(false)
  const [lastSync, setLastSync] = useState(null)

  useEffect(() => {
    // Check initial online status
    setIsOnline(navigator.onLine)

    const handleOnline = () => {
      setIsOnline(true)
      handleSync()
    }

    const handleOffline = () => {
      setIsOnline(false)
    }

    const handleSync = async () => {
      setSyncing(true)
      // Simulate sync process
      setTimeout(() => {
        setSyncing(false)
        setLastSync(new Date())
      }, 2000)
    }

    // Listen for online/offline events
    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Listen for custom sync events
    window.addEventListener("background-sync", handleSync)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
      window.removeEventListener("background-sync", handleSync)
    }
  }, [])

  if (!isOnline) {
    return (
      <Badge variant="secondary" className="flex items-center gap-1">
        <WifiOff className="h-3 w-3" />
        Offline
      </Badge>
    )
  }

  if (syncing) {
    return (
      <Badge variant="outline" className="flex items-center gap-1">
        <RefreshCw className="h-3 w-3 animate-spin" />
        Syncing...
      </Badge>
    )
  }

  return (
    <Badge variant="outline" className="flex items-center gap-1 text-green-600 border-green-200">
      <CheckCircle className="h-3 w-3" />
      Online
    </Badge>
  )
}
