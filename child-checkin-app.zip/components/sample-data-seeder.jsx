"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { Database, CheckCircle, Users, Clock } from "lucide-react"

export function SampleDataSeeder() {
  const [loading, setLoading] = useState(false)
  const [seeded, setSeeded] = useState(false)
  const { toast } = useToast()

  const seedSampleData = async () => {
    setLoading(true)

    try {
      // Create sample users
      const sampleUsers = [
        {
          id: "admin-1",
          email: "admin@school.com",
          name: "School Administrator",
          role: "admin",
          password: "admin123",
          createdAt: new Date().toISOString(),
        },
        {
          id: "parent-1",
          email: "john.doe@email.com",
          name: "John Doe",
          role: "parent",
          password: "parent123",
          createdAt: new Date().toISOString(),
        },
        {
          id: "parent-2",
          email: "jane.smith@email.com",
          name: "Jane Smith",
          role: "parent",
          password: "parent123",
          createdAt: new Date().toISOString(),
        },
      ]

      // Create sample children
      const sampleChildren = [
        {
          id: "child-1",
          name: "Emma Doe",
          grade: "2nd Grade",
          parentId: "parent-1",
          parentEmail: "john.doe@email.com",
          status: "out",
          location: "Home",
          lastUpdated: new Date().toISOString(),
        },
        {
          id: "child-2",
          name: "Liam Doe",
          grade: "Kindergarten",
          parentId: "parent-1",
          parentEmail: "john.doe@email.com",
          status: "in",
          location: "School",
          lastUpdated: new Date().toISOString(),
        },
        {
          id: "child-3",
          name: "Sophia Smith",
          grade: "1st Grade",
          parentId: "parent-2",
          parentEmail: "jane.smith@email.com",
          status: "out",
          location: "Home",
          lastUpdated: new Date().toISOString(),
        },
      ]

      // Create sample requests
      const sampleRequests = [
        {
          id: "request-1",
          childId: "child-1",
          childName: "Emma Doe",
          parentId: "parent-1",
          action: "in",
          status: "pending",
          timestamp: new Date().toISOString(),
          reason: "Early drop-off for field trip",
        },
        {
          id: "request-2",
          childId: "child-3",
          childName: "Sophia Smith",
          parentId: "parent-2",
          action: "out",
          status: "approved",
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          adminResponse: "Approved for doctor appointment",
        },
      ]

      // Store in localStorage
      localStorage.setItem("offlineUsers", JSON.stringify(sampleUsers))
      localStorage.setItem("children", JSON.stringify(sampleChildren))
      localStorage.setItem("requests", JSON.stringify(sampleRequests))

      setSeeded(true)
      toast({
        title: "Sample data loaded successfully!",
        description: "You can now test the system with sample accounts and data.",
      })
    } catch (error) {
      console.error("Error seeding sample data:", error)
      toast({
        title: "Error loading sample data",
        description: "Please try again.",
        variant: "destructive",
      })
    }

    setLoading(false)
  }

  const clearData = () => {
    localStorage.removeItem("offlineUsers")
    localStorage.removeItem("children")
    localStorage.removeItem("requests")
    localStorage.removeItem("currentUser")
    setSeeded(false)
    toast({
      title: "Sample data cleared",
      description: "All sample data has been removed.",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5 text-green-600" />
          Sample Data
        </CardTitle>
        <CardDescription>Load test data to explore the system features</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {seeded && (
          <Alert className="border-green-200 bg-green-50 dark:bg-green-900/20">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800 dark:text-green-200">
              Sample data has been loaded successfully!
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-3">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            <p className="font-medium mb-2">Sample data includes:</p>
            <ul className="space-y-1">
              <li className="flex items-center gap-2">
                <Users className="h-3 w-3" />
                <span>3 user accounts (1 admin, 2 parents)</span>
              </li>
              <li className="flex items-center gap-2">
                <Users className="h-3 w-3" />
                <span>3 children with different statuses</span>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-3 w-3" />
                <span>Sample check-in/out requests</span>
              </li>
            </ul>
          </div>

          <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <h4 className="font-semibold text-sm mb-2">Test Accounts:</h4>
            <div className="text-xs space-y-1">
              <div>
                <strong>Admin:</strong> admin@school.com / admin123
              </div>
              <div>
                <strong>Parent 1:</strong> john.doe@email.com / parent123
              </div>
              <div>
                <strong>Parent 2:</strong> jane.smith@email.com / parent123
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={seedSampleData} disabled={loading} className="flex-1">
              {loading ? "Loading..." : seeded ? "Reload Sample Data" : "Load Sample Data"}
            </Button>
            {seeded && (
              <Button variant="outline" onClick={clearData} className="bg-transparent">
                Clear Data
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
