"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Server, Database, Shield, Globe, Settings, CheckCircle, AlertTriangle, ExternalLink } from "lucide-react"

export function SetupInstructions() {
  return (
    <div className="space-y-6">
      <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-900/20">
        <AlertTriangle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-800 dark:text-blue-200">
          This system currently runs in demo mode with local storage. Follow these instructions to set up a production
          environment.
        </AlertDescription>
      </Alert>

      <div className="grid gap-6">
        {/* Backend Setup */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5 text-green-600" />
              Backend Setup
            </CardTitle>
            <CardDescription>Configure the server-side components</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Badge variant="outline">1</Badge>
                Choose Your Backend Technology
              </h4>
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <p>Select one of the following backend options:</p>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>
                    <strong>Node.js + Express:</strong> Fast setup with JavaScript
                  </li>
                  <li>
                    <strong>Python + FastAPI:</strong> Included in the project files
                  </li>
                  <li>
                    <strong>Java + Spring Boot:</strong> Enterprise-grade solution
                  </li>
                  <li>
                    <strong>Next.js API Routes:</strong> Full-stack React solution
                  </li>
                </ul>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Badge variant="outline">2</Badge>
                API Endpoints Required
              </h4>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="font-medium mb-1">Authentication:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>POST /api/auth/login</li>
                      <li>POST /api/auth/register</li>
                      <li>POST /api/auth/logout</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">Children Management:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>GET /api/children</li>
                      <li>POST /api/children</li>
                      <li>PUT /api/children/:id</li>
                      <li>DELETE /api/children/:id</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">Requests:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>GET /api/requests</li>
                      <li>POST /api/requests</li>
                      <li>PUT /api/requests/:id</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">Check-ins:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>POST /api/checkin</li>
                      <li>POST /api/checkout</li>
                      <li>GET /api/checkin-history</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Database Setup */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-600" />
              Database Configuration
            </CardTitle>
            <CardDescription>Set up your data storage</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Badge variant="outline">1</Badge>
                Database Options
              </h4>
              <div className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>
                    <strong>PostgreSQL:</strong> Recommended for production
                  </li>
                  <li>
                    <strong>MySQL:</strong> Popular relational database
                  </li>
                  <li>
                    <strong>SQLite:</strong> Good for development/small deployments
                  </li>
                  <li>
                    <strong>MongoDB:</strong> NoSQL option for flexible schemas
                  </li>
                </ul>
              </div>
            </div>

            <Separator />

            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Badge variant="outline">2</Badge>
                Required Tables/Collections
              </h4>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="font-medium mb-1">Core Tables:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>users (parents, admins)</li>
                      <li>children (child profiles)</li>
                      <li>requests (check-in/out requests)</li>
                      <li>checkin_records (history)</li>
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium mb-1">Optional Tables:</p>
                    <ul className="list-disc list-inside space-y-1 text-xs">
                      <li>notifications</li>
                      <li>audit_logs</li>
                      <li>settings</li>
                      <li>sessions</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Setup */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-red-600" />
              Security Configuration
            </CardTitle>
            <CardDescription>Implement proper security measures</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">Authentication</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Password hashing (bcrypt)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    JWT tokens for sessions
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Role-based access control
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Session timeout
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Data Protection</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    HTTPS/SSL encryption
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Input validation
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    SQL injection prevention
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    CORS configuration
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Deployment */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-purple-600" />
              Deployment Options
            </CardTitle>
            <CardDescription>Deploy your application to production</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">Frontend Deployment</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    Vercel (recommended for Next.js)
                  </li>
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    Netlify
                  </li>
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    AWS Amplify
                  </li>
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    GitHub Pages
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Backend Deployment</h4>
                <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    Railway
                  </li>
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    Heroku
                  </li>
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    AWS EC2/ECS
                  </li>
                  <li className="flex items-center gap-2">
                    <ExternalLink className="h-3 w-3" />
                    DigitalOcean
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Environment Variables */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-orange-600" />
              Environment Configuration
            </CardTitle>
            <CardDescription>Required environment variables</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm font-mono">
              <div className="space-y-1">
                <div># Database</div>
                <div>DATABASE_URL=your_database_connection_string</div>
                <div></div>
                <div># Authentication</div>
                <div>JWT_SECRET=your_jwt_secret_key</div>
                <div>JWT_EXPIRES_IN=24h</div>
                <div></div>
                <div># API</div>
                <div>NEXT_PUBLIC_API_URL=https://your-api-domain.com/api</div>
                <div></div>
                <div># Optional: Email notifications</div>
                <div>SMTP_HOST=your_smtp_host</div>
                <div>SMTP_USER=your_smtp_username</div>
                <div>SMTP_PASS=your_smtp_password</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
