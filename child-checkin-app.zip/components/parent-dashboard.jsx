"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Users, Plus, LogIn, LogOut, Clock, CheckCircle, XCircle, AlertCircle, User, History } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { SyncStatus } from "@/components/sync-status"
import { ThemeToggle } from "@/components/theme-toggle"

export function ParentDashboard() {
  const [children, setChildren] = useState([])
  const [requests, setRequests] = useState([])
  const [isAddingChild, setIsAddingChild] = useState(false)
  const [newChild, setNewChild] = useState({ name: "", grade: "" })
  const [isOnline, setIsOnline] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    loadData()

    // Check online status
    setIsOnline(navigator.onLine)
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  const loadData = () => {
    try {
      const savedChildren = localStorage.getItem("children")
      const savedRequests = localStorage.getItem("requests")

      if (savedChildren) {
        setChildren(JSON.parse(savedChildren))
      }

      if (savedRequests) {
        setRequests(JSON.parse(savedRequests))
      }
    } catch (error) {
      console.error("Error loading data:", error)
    }
  }

  const saveData = (newChildren, newRequests) => {
    try {
      if (newChildren) {
        localStorage.setItem("children", JSON.stringify(newChildren))
      }
      if (newRequests) {
        localStorage.setItem("requests", JSON.stringify(newRequests))
      }
    } catch (error) {
      console.error("Error saving data:", error)
    }
  }

  const addChild = () => {
    if (!newChild.name.trim() || !newChild.grade) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      })
      return
    }

    const child = {
      id: Date.now().toString(),
      name: newChild.name.trim(),
      grade: newChild.grade,
      status: "out",
      lastUpdated: new Date().toISOString(),
      parent: "current-parent",
    }

    const updatedChildren = [...children, child]
    setChildren(updatedChildren)
    saveData(updatedChildren, null)

    setNewChild({ name: "", grade: "" })
    setIsAddingChild(false)

    toast({
      title: "Success",
      description: `${child.name} has been added`,
    })
  }

  const sendRequest = (childId, action) => {
    const child = children.find((c) => c.id === childId)
    if (!child) return

    const request = {
      id: Date.now().toString(),
      childId,
      childName: child.name,
      action,
      status: "pending",
      timestamp: new Date().toISOString(),
      parent: "current-parent",
    }

    const updatedRequests = [...requests, request]
    setRequests(updatedRequests)
    saveData(null, updatedRequests)

    toast({
      title: "Request Sent",
      description: `${action === "in" ? "Check-in" : "Check-out"} request sent for ${child.name}`,
      variant: isOnline ? "default" : "secondary",
    })
  }

  const getStatusColor = (status) => {
    switch (status) {
      case "in":
        return "bg-green-500"
      case "out":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  const getRequestStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "secondary"
      case "approved":
        return "default"
      case "rejected":
        return "destructive"
      default:
        return "outline"
    }
  }

  const getRequestIcon = (status) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "rejected":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const grades = [
    "Pre-K",
    "Kindergarten",
    "1st Grade",
    "2nd Grade",
    "3rd Grade",
    "4th Grade",
    "5th Grade",
    "6th Grade",
    "7th Grade",
    "8th Grade",
    "9th Grade",
    "10th Grade",
    "11th Grade",
    "12th Grade",
  ]

  const pendingRequests = requests.filter((r) => r.status === "pending")
  const recentRequests = requests.slice(-5).reverse()

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <User className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Parent Dashboard</h1>
              <p className="text-gray-600 dark:text-gray-300">Manage your children's check-in status</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <SyncStatus />
            <ThemeToggle />
          </div>
        </div>

        {!isOnline && (
          <Alert className="mb-6 border-orange-200 bg-orange-50 dark:bg-orange-900/20">
            <AlertCircle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800 dark:text-orange-200">
              You're currently offline. Requests will be sent when connection is restored.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Children Management */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  My Children ({children.length})
                </CardTitle>
                <Dialog open={isAddingChild} onOpenChange={setIsAddingChild}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Child
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Child</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="name">Child's Name</Label>
                        <Input
                          id="name"
                          value={newChild.name}
                          onChange={(e) => setNewChild({ ...newChild, name: e.target.value })}
                          placeholder="Enter child's name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="grade">Grade</Label>
                        <Select
                          value={newChild.grade}
                          onValueChange={(value) => setNewChild({ ...newChild, grade: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select grade" />
                          </SelectTrigger>
                          <SelectContent>
                            {grades.map((grade) => (
                              <SelectItem key={grade} value={grade}>
                                {grade}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsAddingChild(false)}>
                          Cancel
                        </Button>
                        <Button onClick={addChild}>Add Child</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {children.length === 0 ? (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No children added yet</p>
                    <p className="text-sm">Click "Add Child" to get started</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {children.map((child) => (
                      <div
                        key={child.id}
                        className="flex items-center justify-between p-4 border rounded-lg dark:border-gray-700"
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(child.status)}`} />
                          <div>
                            <h3 className="font-semibold text-gray-900 dark:text-white">{child.name}</h3>
                            <p className="text-sm text-gray-600 dark:text-gray-300">{child.grade}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={child.status === "in" ? "default" : "secondary"}>
                            {child.status === "in" ? "Checked In" : "Checked Out"}
                          </Badge>
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              variant={child.status === "in" ? "outline" : "default"}
                              onClick={() => sendRequest(child.id, "in")}
                              disabled={child.status === "in"}
                            >
                              <LogIn className="h-4 w-4 mr-1" />
                              Check In
                            </Button>
                            <Button
                              size="sm"
                              variant={child.status === "out" ? "outline" : "default"}
                              onClick={() => sendRequest(child.id, "out")}
                              disabled={child.status === "out"}
                            >
                              <LogOut className="h-4 w-4 mr-1" />
                              Check Out
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Requests Panel */}
          <div className="space-y-6">
            {/* Pending Requests */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Pending Requests ({pendingRequests.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {pendingRequests.length === 0 ? (
                  <p className="text-gray-500 dark:text-gray-400 text-sm text-center py-4">No pending requests</p>
                ) : (
                  <div className="space-y-3">
                    {pendingRequests.map((request) => (
                      <div key={request.id} className="p-3 border rounded-lg dark:border-gray-700">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900 dark:text-white">{request.childName}</span>
                          <Badge variant={getRequestStatusColor(request.status)}>
                            {getRequestIcon(request.status)}
                            <span className="ml-1">{request.status}</span>
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {request.action === "in" ? "Check-in" : "Check-out"} request
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(request.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recentRequests.length === 0 ? (
                  <p className="text-gray-500 dark:text-gray-400 text-sm text-center py-4">No recent activity</p>
                ) : (
                  <div className="space-y-3">
                    {recentRequests.map((request) => (
                      <div key={request.id} className="p-3 border rounded-lg dark:border-gray-700">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-gray-900 dark:text-white">{request.childName}</span>
                          <Badge variant={getRequestStatusColor(request.status)}>
                            {getRequestIcon(request.status)}
                            <span className="ml-1">{request.status}</span>
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {request.action === "in" ? "Check-in" : "Check-out"} request
                        </p>
                        {request.adminResponse && (
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            Response: {request.adminResponse}
                          </p>
                        )}
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(request.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
