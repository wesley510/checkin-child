"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { apiService } from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useToast } from "@/hooks/use-toast"
import { Eye, EyeOff, Shield, ArrowLeft, AlertCircle } from "lucide-react"
import { OfflineIndicator } from "@/components/offline-indicator"

export default function AdminLoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { toast } = useToast()
  const router = useRouter()

  const handleSignIn = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const response = await apiService.login(email, password, "admin")
      if (response.success) {
        const user = {
          id: response.user.id,
          email: response.user.email,
          name: response.user.name,
          role: "admin",
        }

        localStorage.setItem("currentUser", JSON.stringify(user))

        const isOffline = apiService.isOffline()
        toast({
          title: isOffline ? "Signed in (Offline Mode)" : "Welcome back, Administrator!",
          description: isOffline
            ? "You're signed in offline. Data will sync when connection is restored."
            : "Successfully signed in to admin dashboard.",
        })
        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Admin sign in error:", error)
      setError(error.message || "Invalid administrator credentials. Please check your email and password.")
    }

    setLoading(false)
  }

  const handleSignUp = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const response = await apiService.register(email, password, name, "admin")
      if (response.success) {
        const user = {
          id: response.user.id,
          email: response.user.email,
          name: response.user.name,
          role: "admin",
        }

        localStorage.setItem("currentUser", JSON.stringify(user))

        const isOffline = apiService.isOffline()
        toast({
          title: isOffline ? "Admin account created (Offline Mode)" : "Admin account created!",
          description: isOffline
            ? "Account created offline. Data will sync when connection is restored."
            : "Welcome to the Child Check-In Admin System.",
        })
        router.push("/dashboard")
      }
    } catch (error) {
      console.error("Admin sign up error:", error)
      setError(error.message || "Failed to create administrator account")
    }

    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <OfflineIndicator />

      <div className="w-full max-w-md">
        <Card className="border-2 border-red-200 dark:border-red-800">
          <CardHeader className="text-center">
            <div className="flex justify-between items-center mb-4">
              <Button variant="ghost" size="sm" onClick={() => router.push("/")} className="p-2">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <CardTitle className="flex items-center justify-center gap-2 flex-1">
                <Shield className="h-6 w-6 text-red-600" />
                Administrator Access
              </CardTitle>
              <div className="w-10" />
            </div>
            <CardDescription>Sign in to manage the child check-in system</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="signin" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="signin">Sign In</TabsTrigger>
                <TabsTrigger value="signup">Create Admin</TabsTrigger>
              </TabsList>

              <TabsContent value="signin">
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signin-email">Administrator Email</Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="Enter your admin email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signin-password">Password</Label>
                    <div className="relative">
                      <Input
                        id="signin-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={loading}>
                    {loading ? "Signing in..." : "Sign In as Administrator"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="signup">
                <form onSubmit={handleSignUp} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-name">Full Name</Label>
                    <Input
                      id="signup-name"
                      type="text"
                      placeholder="Enter your full name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Administrator Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="Enter your admin email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <div className="relative">
                      <Input
                        id="signup-password"
                        type={showPassword ? "text" : "password"}
                        placeholder="Create a secure password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" disabled={loading}>
                    {loading ? "Creating account..." : "Create Administrator Account"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            <div className="mt-6 p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <h4 className="font-semibold text-sm text-red-800 dark:text-red-200 mb-2">Administrator Privileges:</h4>
              <ul className="text-xs text-red-700 dark:text-red-300 space-y-1">
                <li>• Manage all children in the system</li>
                <li>• Approve or reject check-in/out requests</li>
                <li>• Override child status when needed</li>
                <li>• View comprehensive reports and analytics</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
