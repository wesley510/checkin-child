"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { OfflineIndicator } from "@/components/offline-indicator"
import { UserCheck, Shield, Users, Database, Settings, ArrowRight } from "lucide-react"

export default function HomePage() {
  const [showSetup, setShowSetup] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Check if user is already logged in
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      router.push("/dashboard")
    }
  }, [router])

  if (showSetup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
        <div className="w-full max-w-2xl">
          <OfflineIndicator />
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-6 w-6" />
                  Setup Instructions
                </CardTitle>
                <Button variant="ghost" onClick={() => setShowSetup(false)}>
                  Back
                </Button>
              </div>
              <CardDescription>Configure your Child Check-In system</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">1. Database Setup</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Configure your database connection in the backend configuration files.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">2. Authentication</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Set up secure authentication with proper password hashing and session management.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">3. Deployment</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Deploy to your preferred hosting platform with proper environment variables.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <OfflineIndicator />

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <UserCheck className="h-12 w-12 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">Child Check-In System</h1>
          </div>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Secure and efficient child check-in/out management for schools, daycares, and childcare facilities
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          {/* Admin Login Card */}
          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-red-200 dark:border-red-800"
            onClick={() => router.push("/admin/login")}
          >
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-red-100 dark:bg-red-900 rounded-full flex items-center justify-center mb-4">
                <Shield className="h-8 w-8 text-red-600 dark:text-red-400" />
              </div>
              <CardTitle className="text-xl text-red-700 dark:text-red-400">Administrator Access</CardTitle>
              <CardDescription>Manage all children, approve requests, and oversee operations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4" />
                  <span>Manage all children</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <UserCheck className="h-4 w-4" />
                  <span>Approve/reject requests</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Database className="h-4 w-4" />
                  <span>View reports & analytics</span>
                </div>
                <Button className="w-full mt-4 bg-red-600 hover:bg-red-700">
                  Admin Sign In
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Parent Login Card */}
          <Card
            className="hover:shadow-lg transition-shadow cursor-pointer border-2 border-blue-200 dark:border-blue-800"
            onClick={() => router.push("/parent/login")}
          >
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mb-4">
                <UserCheck className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle className="text-xl text-blue-700 dark:text-blue-400">Parent Access</CardTitle>
              <CardDescription>Manage your children and send check-in/out requests</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Users className="h-4 w-4" />
                  <span>Manage your children</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <UserCheck className="h-4 w-4" />
                  <span>Send check-in/out requests</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <Database className="h-4 w-4" />
                  <span>View your child's status</span>
                </div>
                <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
                  Parent Sign In
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Features Section */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8 text-gray-900 dark:text-white">Key Features</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold mb-2 text-gray-900 dark:text-white">Real-time Check-ins</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Instant check-in/out tracking with live status updates for parents and administrators.
              </p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold mb-2 text-gray-900 dark:text-white">Offline Support</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Works seamlessly offline with automatic sync when connection is restored.
              </p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold mb-2 text-gray-900 dark:text-white">Request System</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Parents can send check-in/out requests that admins can approve or reject with reasons.
              </p>
            </div>
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
              <h3 className="font-semibold mb-2 text-gray-900 dark:text-white">Secure Access</h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Role-based authentication ensures only authorized users can access child information.
              </p>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" onClick={() => setShowSetup(true)}>
            <Settings className="h-4 w-4 mr-2" />
            Setup Guide
          </Button>
        </div>
      </div>
    </div>
  )
}
